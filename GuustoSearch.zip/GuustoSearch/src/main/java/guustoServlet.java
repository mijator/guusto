

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class servlet
 */

@WebServlet("/GuustoSearch/servlet")
public class guustoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	 /**
     * Default constructor. 
     */
	
	private String mymsg = "Hello Guusto!";
	
    public guustoServlet() {
        // TODO Auto-generated constructor stub 
    	System.out.println("Hello" + mymsg);
    }
   
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		//PrinterWriter pwriter = response.getWriter(); 
		
		try {
			response.setContentType("text/html");
			
			
			String user = request.getParameter("userName");
			String pass = request.getParameter("passWord");
			
			response.getWriter().print("Name is: " + user); 
			response.getWriter().print("Password is: " + pass); 
			
			if (user.equals("jrota") && pass.equals("test")) 
				response.getWriter().print("Login success");
			else 
				response.getWriter().print("Login failed");
			
			response.getWriter().close();
			
		} catch  (Exception e) {
			System.out.println(e);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}



